let coins=1000, bet=0, active=false;
const $=id=>document.getElementById(id);
async function state(){
 const r=await fetch("/api/state"); const d=await r.json();
 $("mult").textContent=d.round.multiplier.toFixed(2)+"x";
 $("status").textContent=d.round.status==="running"?"FLYING":d.round.status==="crashed"?"CRASHED":"Waiting…";
 $("start").disabled=d.round.status==="running";
 $("history").innerHTML=d.history.map(x=>`#${x.id} — ${x.crashAt.toFixed(2)}x`).join("<br>")||"No rounds yet";
 const p=Math.min(80,8+(d.round.multiplier-1)*4); $("plane").style.left=p+"%";
 if(active && d.round.status==="crashed"){active=false; $("cashBtn").disabled=true; $("betBtn").disabled=false; $("msg").textContent=`Round crashed at ${d.round.crashAt.toFixed(2)}x`; }
}
$("start").onclick=async()=>{await fetch("/api/admin/start",{method:"POST"});state()};
$("save").onclick=async()=>{await fetch("/api/admin/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({minCrash:$("min").value,maxCrash:$("max").value})});$("msg").textContent="Demo settings saved."};
$("betBtn").onclick=()=>{const n=Number($("bet").value);if(n<1||n>coins)return $("msg").textContent="Invalid virtual coin amount.";bet=n;coins-=n;active=true;$("coins").textContent=coins;$("betBtn").disabled=true;$("cashBtn").disabled=false;$("msg").textContent=`Bet placed: ${n} virtual coins.`};
$("cashBtn").onclick=async()=>{if(!active)return;const r=await fetch("/api/state");const d=await r.json();if(d.round.status!=="running")return;const payout=Math.floor(bet*d.round.multiplier);coins+=payout;active=false;$("cashBtn").disabled=true;$("betBtn").disabled=false;$("coins").textContent=coins;$("msg").textContent=`Cashed out at ${d.round.multiplier.toFixed(2)}x: +${payout} virtual coins.`};
setInterval(state,100);state();