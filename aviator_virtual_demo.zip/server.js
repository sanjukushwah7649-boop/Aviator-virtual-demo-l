const express = require("express");
const path = require("path");
const crypto = require("crypto");
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

let round = { id: 1, status:"waiting", multiplier:1, crashAt:null, startedAt:null };
let history = [];
let settings = { minCrash:1.2, maxCrash:20 };

function newCrashPoint(){
  const u = crypto.randomInt(1_000_000, 9_999_999)/10_000_000;
  const x = settings.minCrash + u*(settings.maxCrash-settings.minCrash);
  return Math.round(x*100)/100;
}
function startRound(){
  if(round.status==="running") return;
  round = {id:round.id+1,status:"running",multiplier:1,crashAt:newCrashPoint(),startedAt:Date.now()};
  const timer=setInterval(()=>{
    if(round.status!=="running") return clearInterval(timer);
    const elapsed=(Date.now()-round.startedAt)/1000;
    round.multiplier=Math.round(Math.exp(elapsed*0.18)*100)/100;
    if(round.multiplier>=round.crashAt){
      round.multiplier=round.crashAt;
      round.status="crashed";
      history.unshift({id:round.id,crashAt:round.crashAt,at:new Date().toISOString()});
      history=history.slice(0,30);
      setTimeout(()=>{round.status="waiting"; round.multiplier=1; round.crashAt=null;},2500);
      clearInterval(timer);
    }
  },50);
}

app.get("/api/state",(req,res)=>res.json({round:{id:round.id,status:round.status,multiplier:round.multiplier},history,settings}));
app.post("/api/admin/start",(req,res)=>{startRound();res.json({ok:true});});
app.post("/api/admin/settings",(req,res)=>{
  const min=Number(req.body.minCrash), max=Number(req.body.maxCrash);
  if(Number.isFinite(min)&&Number.isFinite(max)&&min>=1.01&&max>min&&max<=100){
    settings.minCrash=min; settings.maxCrash=max;
  }
  res.json({ok:true,settings});
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(3000,()=>console.log("Demo running at http://localhost:3000"));
